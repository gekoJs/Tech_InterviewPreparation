function clockMinuteAdder (time, minutesToAdd) {
  // Your code here:

}

module.exports = clockMinuteAdder
