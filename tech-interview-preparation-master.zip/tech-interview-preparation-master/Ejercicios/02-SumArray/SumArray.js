function SumArray (arr, n) {
  // Your code here:

}

module.exports = SumArray
