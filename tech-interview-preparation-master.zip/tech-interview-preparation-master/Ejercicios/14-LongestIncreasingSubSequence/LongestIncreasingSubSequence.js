function longestIncreasingSubsequence (nums) {
  // Your code here:

}

module.exports = longestIncreasingSubsequence
