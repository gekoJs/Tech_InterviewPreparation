![HenryLogo](https://d31uz8lwfmyn8g.cloudfront.net/Assets/logo-henry-white-lg.png)

# Decimal to Binary

## Introducción

En el caso anterior transformábamos números binarios en decimales. En este caso hay que **hacer una función que tome un número decimal y lo devuelva en binario**

## Solución

### En palabras

1. Tomá el número y sacá su modulo en 2
2. Guardá el resultado en un string
3. Dividí el número por 2 y redondealo para abajo
4. Continúa el proceso hasta que el número sea igual a 0
5. Devuelve el string
