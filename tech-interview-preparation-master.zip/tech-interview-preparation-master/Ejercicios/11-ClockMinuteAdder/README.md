![HenryLogo](https://d31uz8lwfmyn8g.cloudfront.net/Assets/logo-henry-white-lg.png)

# Clock minute adder

## Introducción

Dada una hora en string en **formato HH:MM**, y un número de minutos.
Devolver la nueva hora pasados esos minutos.

### IMPORTANTE

El reloj es de 12 horas y tiene que devolverse en el formato HH:MM. Recuerda que no existen las 00hs.

### Ejemplos

clockMinuteAdder (**'09:00', 20**);
**ouput**: '09:20'

clockMinuteAdder (**'01:30', 30**);
**ouput**: '02:00'

clockMinuteAdder (**'12:05', 100**);
**ouput**: '01:45'

---
