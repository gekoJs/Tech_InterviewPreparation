<p>
        <img src='https://static.wixstatic.com/media/85087f_0d84cbeaeb824fca8f7ff18d7c9eaafd~mv2.png/v1/fill/w_160,h_30,al_c,q_85,usm_0.66_1.00_0.01/Logo_completo_Color_1PNG.webp' </img>
</p>

# Longest Increasing Subsequence

## Introducción

Dado un arreglo de números, encontrá el length de la secuencia creciente mas larga posible. Esta secuencia puede saltear números en el arreglo.

### Ejemplos

**input:** [3,10,4,5]
La **secuencia es [3,4,5]**  
**output:** 3.

longestIncreasingSubsequence(**[3, 4, 2, 1, 10, 6]**);
Donde la **secuencia** es: 3, 4, 6
**output**: 3

longestIncreasingSubsequence(**[10, 22, 9, 33, 20, 50, 41, 60, 80]**);  
Donde la **secuencia** es: 10, 22, 33, 41, 60, 80 (or 10, 22, 33, 50, 60, 80)
**output**: 6

longestIncreasingSubsequence(**[10, 22, 9, 33, 20, 50, 41, 60, 80, 21, 23, 24, 25, 26, 27, 28]**);  
Donde, la **secuencia** es: 10, 20, 21, 23, 24, 25, 26, 27, 28  
**output**: 9
