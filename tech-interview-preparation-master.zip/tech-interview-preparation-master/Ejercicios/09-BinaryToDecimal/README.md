![HenryLogo](https://d31uz8lwfmyn8g.cloudfront.net/Assets/logo-henry-white-lg.png)

# Binary to Decimal

## Introducción

Escribe una función que pase un string en binario a un número decimal

## Solución

### En palabras

1. Iterar sobre cada número
2. Ir sumando: la potencia de 2 y, su posición, multiplicada por el número [1 ó 0].
