![HenryLogo](https://d31uz8lwfmyn8g.cloudfront.net/Assets/logo-henry-white-lg.png)

# Intersection

## Introducción

Dado dos arreglos **ordenados** devuelve un
arreglo con los números que se repiten.

### Ejemplos

**input**: [1,3,5,7,10], [2,3,6,8,10,20]  
**output**: [3, 10]

---
