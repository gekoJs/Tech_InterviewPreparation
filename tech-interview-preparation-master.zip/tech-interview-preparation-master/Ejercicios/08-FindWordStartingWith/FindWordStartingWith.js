function FindWordStartingWith (book, query) {
  // Your code here:

}

module.exports = FindWordStartingWith
