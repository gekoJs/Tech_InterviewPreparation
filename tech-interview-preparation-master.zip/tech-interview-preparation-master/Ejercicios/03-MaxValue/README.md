![HenryLogo](https://d31uz8lwfmyn8g.cloudfront.net/Assets/logo-henry-white-lg.png)

# Max Value

## Introducción

Se nos presenta un arreglo de enteros, éstos representan el valor de una acción con el pasar del tiempo. ¿El objetivo del ejercicio? Encontrar cuál es la máxima ganancia posible de comprar en un momento y vender en otro posterior.

### Ejemplo

- **acciones**: [4, 3, 2, 5, 11]
- **mayor ganancia**: 9

Esta ganancia la obtenemos comprando la acción cuando su valor es de 2 y vendiéndola cuando su valor es de 11.

---

