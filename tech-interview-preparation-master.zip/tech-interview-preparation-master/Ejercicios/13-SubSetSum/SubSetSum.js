function subsetSum (nums, n) {
  // Your code here:

}

module.exports = subsetSum
